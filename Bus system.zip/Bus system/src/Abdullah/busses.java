package Abdullah;

public class busses  {
    int no_of_busses=4;
    String area1="islamabad";
    String area2="rawalpindi";
    String area3="rawat";
    String area4="txila";
    int no_of_seats_in_buss=12;
    String dname1="Abdullah";
    String dname2="Hamza";
    String dname3="Haider";
    String dname4="Huzaifa";
    long driver1=0311165763L;
    long driver2=0355565763L;
    long driver3=0333365763L;
    long driver4=0322265763L;
    String Time1="08:00_AM_to_01:00_pm";
    String Time2="08:30_AM_to_02:00_pm";
    String Time3="09:00_AM_to_02:30_pm";
    String Time4="10:00_AM_to_03:00_pm";
    void display()
    {
        System.out.println(" **********************************************************");
        System.out.println(" Total Busses are :"+no_of_busses);
        System.out.println(" Total seats in busses are :"+no_of_seats_in_buss);
        System.out.println(" ************************* Bus1 **************************");
        System.out.println(" Area of Bus 1 : "+area1);
        System.out.println(" Driver Name : "+dname1);
        System.out.println(" Drive Number : "+driver1);
        System.out.println(" Timings : "+Time1);
        System.out.println(" **********************************************************");
        System.out.println("");
        System.out.println(" ************************* Bus2 **************************");
        System.out.println(" Area of Bus 2 : "+area2);
        System.out.println(" Driver Name : "+dname2);
        System.out.println(" Drive Number : "+driver2);
        System.out.println(" Timings : "+Time2);
        System.out.println(" **********************************************************");
        System.out.println("");
        System.out.println(" ************************* Bus3 **************************");
        System.out.println(" Area of Bus 3 : "+area3);
        System.out.println(" Driver Name : "+dname3);
        System.out.println(" Drive Number : "+driver3);
        System.out.println(" Timings : "+Time3);
        System.out.println(" **********************************************************");
        System.out.println("");
        System.out.println(" ************************* Bus4 **************************");
        System.out.println(" Area of Bus 4 : "+area4);
        System.out.println(" Driver Name : "+dname4);
        System.out.println(" Drive Number : "+driver4);
        System.out.println(" Timings : "+Time4);
        System.out.println(" **********************************************************");
    }
}

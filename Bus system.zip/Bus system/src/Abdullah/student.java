package Abdullah;
import java.util.Scanner;

public class student extends  busses{
    busses bobj=new busses();
    Scanner sc=new Scanner(System.in);
    Scanner scString=new Scanner(System.in);
    String StudentName;
    int Sap_id;
    String area;
    int a;
    void registration_form()
    {
        System.out.print(" Enter name of Student : ");
        StudentName = scString.nextLine();
        System.out.print(" Enter SAP_ID :");
        Sap_id=sc.nextInt();
        System.out.println(" Area Code ");
        System.out.print(" Enter Area where you want to go : ");
        System.out.println(" 1.Islamabad\n 2.rawalpindi");
        System.out.println(" 3.Rawat/n 4.Tixla");
        System.out.println(" enter your choice : ");
        a=sc.nextInt();
        area=scString.nextLine();
        if (a== 1)
        {
            System.out.println(" Your selected area is : "+area);
            System.out.println(" Your Driver name is : "+bobj.dname1);
            System.out.println(" Your Driver number is : "+bobj.driver1);
            System.out.println(" Your Time is : "+bobj.Time1);
        }
        else if(a==2)
        {
            System.out.println(" Your selected area is : "+area);
            System.out.println(" Your Driver name is : "+bobj.dname2);
            System.out.println(" Your Driver number is : "+bobj.driver2);
            System.out.println(" Your Time is : "+bobj.Time2);
        }
        else if (a== 3)
        {
            System.out.println(" Your selected area is : "+area);
            System.out.println(" Your Driver name is : "+bobj.dname3);
            System.out.println(" Your Driver number is : "+bobj.driver3);
            System.out.println(" Your Time is : "+bobj.Time3);
        }
        else if (a== 4)
        {
            System.out.println(" Your selected area is : "+area);
            System.out.println(" Your Driver name is : "+bobj.dname4);
            System.out.println(" Your Driver number is : "+bobj.driver4);
            System.out.println(" Your Time is : "+bobj.Time4);
        }
    }
}


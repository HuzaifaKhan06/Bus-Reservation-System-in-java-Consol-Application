package Abdullah;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        busses b_obj = new busses();
        student s_obj=new student();
        charges c_obj = new charges();
        int x=-1;
        do{
            int a;

            System.out.println(" <<<** Busses **>>          <<<** Student Registration **>>");
            System.out.println(" Press 1 for Busses");
            System.out.println(" Press 2 for Registration  ");
            System.out.print(" Enter your choice : ");
            a=sc.nextInt();
            if (a==1)
            {
                b_obj.display();
            } else if (a==2)
            {
                s_obj.registration_form();
            }
            else
            {
                System.out.println(" Choose again ! ");
            }
            System.out.println(" Press 1 to continue \n press1 0 to next ");
            System.out.println(" enter : ");
            x=sc.nextInt();
        }while(x!=0);
        int y=-1;
        do {
            int b;
            System.out.println(" Press 2 to Continue ........ ");
            System.out.println(" enter : ");
            b=sc.nextInt();
            if(b==2)
            {
                c_obj.charges();
                c_obj.per_day();
            }
            else
            {
                System.out.println(" You enter wrong ");
            }
            System.out.println(" Press 1 for end  ");
            System.out.println(" enter : ");
            y=sc.nextInt();
        }while(y!=1);
    }
}

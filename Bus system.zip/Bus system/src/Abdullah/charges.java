package Abdullah;
import java.sql.SQLOutput;
import java.util.Scanner;
public class charges extends student{
    Scanner sc=new Scanner(System.in);
    student sobj=new student();
    int per_day_charges=1;
    int monthly_charges=30;

    int fair=100;

    int choice;
    int ac;
    void charges()
    {
        System.out.println(" You want to pay the charges \n Per Day \n Per Month");
        System.out.println(" Press 1 for Per Day Charges \n Press 2 for Monthly Charges ");
        System.out.print(" Enter your Choice : ");
        choice=sc.nextInt();
        System.out.println(" Enter your area code : ");
        ac=sc.nextInt();

    }
    void per_day()
    {
        if (choice==1)
        {

                System.out.println(" Your Charges per day is : "+(per_day_charges*fair));

        } else if (choice==2)
        {

                System.out.println(" Your Monthly Charges is : "+(monthly_charges*fair));

        }
        else
        {
            System.out.println(" You enter wrong ...!");
        }
    }

}
